function TestConstants_SHOWCLEF_()
   NumberConstantTest(finale.SHOWCLEF_ALWAYS, "SHOWCLEF_ALWAYS", 2)
   NumberConstantTest(finale.SHOWCLEF_HIDE, "SHOWCLEF_HIDE", 1)
   NumberConstantTest(finale.SHOWCLEF_NORMAL, "SHOWCLEF_NORMAL", 0)
end

-- Test the constants:
TestConstants_SHOWCLEF_()
