function plugindef()   -- This function and the 'finaleplugin' namespace   -- are both reserved for the plug-in definition.   finaleplugin.NoStore = true   return "JW Lua Class Tests", "Class Tests", "Test the validity of JW Lua classes"end

-- Load the toolkit  functions needed for the tests:
require("jwluatesttools")

-- Load and execute the unit tests for the classes:
require("jwluatest_fcarticulationdef")
require("jwluatest_fcmeasure")
require("jwluatest_fcnumber")
require("jwluatest_fcpage")
require("jwluatest_fcpageformatprefs")
require("jwluatest_fcstaffsystem")

-- Output the results from the tests:
PrintTestResult()

