function plugindef()   -- This function and the 'finaleplugin' namespace   -- are both reserved for the plug-in definition.   finaleplugin.NoStore = true   return "JW Lua - All Tests", "All Tests", "Run all the JW Lua tests. Requires the debug file template."end


-- Load the toolkit  functions needed for the tests:
require("jwlua_classtests")
require("jwlua_consttests")
require("jwlua_filetests")

-- No need to output the result, since that's already been done

