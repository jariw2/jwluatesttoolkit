function FCTextRepeatDef_ValueTests_ItemNo1(textrepeatdef)
   NumberValuePropertyTest(textrepeatdef, "FCTextRepeatDef", "Justification", finale.TEXTREPJUST_RIGHT)
   NumberValuePropertyTest(textrepeatdef, "FCTextRepeatDef", "ReplaceMode", finale.REPEATREPLACE_TIMESPLAYED)
   BoolValuePropertyTest(textrepeatdef, "FCTextRepeatDef", "UseThisFont", false)
   AssureValue(textrepeatdef:CreateTextString().LuaString, "D.C. al Fine", "textrepeatdef:CreateString().LuaString")
end


-- Call:
local textrepeatdef = finale.FCTextRepeatDef()
AssureTrue(textrepeatdef:Load(1))
FCTextRepeatDef_ValueTests_ItemNo1(textrepeatdef)
