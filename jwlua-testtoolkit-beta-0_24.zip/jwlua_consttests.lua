function plugindef()   -- This function and the 'finaleplugin' namespace   -- are both reserved for the plug-in definition.   finaleplugin.NoStore = true   return "JW Lua Constants Tests", "Constants Tests", "Test the validity of the JW Lua constants."end

-- Load the toolkit  functions needed for the tests:
require("tools/jwluatesttools")

-- Load and execute the unit tests for the classes:
require("constanttests/consttest_fccategorydef")
require("constanttests/consttest_fcmeasure")
require("constanttests/consttest_fctextrepeatdef")

-- Output the results from the tests:
PrintTestResult()

