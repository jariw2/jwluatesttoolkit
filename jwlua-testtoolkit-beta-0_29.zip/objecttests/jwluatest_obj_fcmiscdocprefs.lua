function FCMiscDocPrefs_ValueTests_ItemNo1(mdprefs)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "AllowFloatingRests", true)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "AlwaysSlashGraceNote", true)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "BeamedCommonTimeEights", true)
   NumberValuePropertyTest(mdprefs, "FCMiscDocPrefs", "ClefResize", 75)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "ConsolidateRestsAcrossLayers", false)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "ExtendBeamsOverRests", false)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "FinalBarlineAtEnd", true)
   BoolValuePropertyTest(mdprefs, "FCMiscDocPrefs", "UseStemConnections", true)
end


-- Call:
local mdprefs = finale.FCMiscDocPrefs()
AssureTrue(mdprefs:Load(1))
FCMiscDocPrefs_ValueTests_ItemNo1(mdprefs)
