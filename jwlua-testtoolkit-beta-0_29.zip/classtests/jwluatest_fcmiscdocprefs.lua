function FCMiscDocPrefs_PropertyTests(mdprefs)
    BoolPropertyTest(mdprefs, "FCMiscDocPrefs", "AllowFloatingRests")
    BoolPropertyTest(mdprefs, "FCMiscDocPrefs", "AlwaysSlashGraceNote")
    PropertyTest(mdprefs, "FCMiscDocPrefs", "BeamedCommonTimeEights")
    NumberPropertyTest(mdprefs, "FCMiscDocPrefs", "ClefResize", {30, 75, 100, 157})
    if Is2014OrAbove() then
        BoolPropertyTest(mdprefs, "FCMiscDocPrefs", "ConsolidateRestsAcrossLayers")
    end
    BoolPropertyTest(mdprefs, "FCMiscDocPrefs", "ExtendBeamsOverRests")
    BoolPropertyTest(mdprefs, "FCMiscDocPrefs", "FinalBarlineAtEnd")
    BoolPropertyTest(mdprefs, "FCMiscDocPrefs", "UseStemConnections")
end


-- Call:
local mdprefs = finale.FCMiscDocPrefs()
AssureTrue(mdprefs:Load(1))
FCMiscDocPrefs_PropertyTests(mdprefs)
