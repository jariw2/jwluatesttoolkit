function plugindef()   -- This function and the 'finaleplugin' namespace   -- are both reserved for the plug-in definition.   finaleplugin.NoStore = true   return "JW Lua File Tests", "File Tests", "Test the validity of JW Lua classes against a specific debug file."end

-- Validate the current file prior to the test:
local fileinfotext = finale.FCFileInfoText()
fileinfotext:LoadDescription()
local str = fileinfotext:CreateString()
str:TrimEnigmaTags()
str:TrimWhitespace()
if str.LuaString ~= "This is the official JW Lua test template." then
    print ("Wrong file is used for the test. Please load the official JW Lua test file.")
    return
end


-- Load the toolkit  functions needed for the tests:
require("tools/jwluatesttools")

-- Load and execute the tests for the classes:
require("objecttests/jwluatest_obj_fccategorydef")
require("objecttests/jwluatest_obj_fcmeasure")
require("objecttests/jwluatest_obj_fctextexpressiondef")

-- Output the results from the tests:
PrintTestResult()

